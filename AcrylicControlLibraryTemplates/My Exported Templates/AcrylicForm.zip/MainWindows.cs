﻿using AcrylicUI.Forms;
using AcrylicUI.Platform.Windows;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class MainWindow : AcrylicForm
    {
        public MainWindow()
        {
            InitializeComponent();
            Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Text = "MainWindow";
            this.BlurOpacity = 190;

        }
        #region Windows AcrylicTheme Hack

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Win32Hacks.DarkThemeTitleBar(this.Handle);
        }

        #endregion

    }
}
